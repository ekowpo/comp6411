# nodejs-sequelize-msql
ORM using sequelize
Mysql
Use of Jade, 
POST of data
GET data
GET data with parameter
Delete Data
Eager fetch data
JSON return data
HTML Return page with data.
