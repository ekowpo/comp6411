# Python-django-mysql

Django
Model creation ORM
Forms
Bootstrap.
